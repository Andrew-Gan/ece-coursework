public class StackObj {
    int offs = 0;
    int val;
}